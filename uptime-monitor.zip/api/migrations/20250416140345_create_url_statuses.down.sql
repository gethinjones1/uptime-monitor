DROP TABLE IF EXISTS url_statuses;
