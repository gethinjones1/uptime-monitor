DROP TABLE IF EXISTS monitored_urls;
