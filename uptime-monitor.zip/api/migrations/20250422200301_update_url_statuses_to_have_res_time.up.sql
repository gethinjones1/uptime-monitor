ALTER TABLE url_statuses ADD COLUMN response_time INTEGER;
